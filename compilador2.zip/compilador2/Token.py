
class Token():
    def __init__(self,cadeia="",classe="",linha="",categoria=""):
        self.cadeia = cadeia
        self.classe = classe
        self.linha = linha
        self.categoria = categoria
